---
title: "Family bakery marks 40 years with a week of special bakes"
description: "Sample article: a Food & Drink story, showing how stories appear in that section."
date: 2026-11-11
category: food-drink
area: South Belfast
---

*This is a sample article to show the layout. Delete it before launch.*

An anniversary story would go here: the history, the family behind it and what's on offer to celebrate.
