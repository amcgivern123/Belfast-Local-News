---
title: "Meet The Gate Guy: 25 years keeping Belfast's driveways secure"
description: "How AutoGate NI grew into a gate and automation business covering Northern Ireland, and what's next for the team."
date: 2026-11-12
category: trades-services
area: Belfast
author: Belfast Local Business
pinned: true
---

For 25 years, Adrian has been installing, automating and repairing electric gates for homes and businesses. Many of his customers simply know him as The Gate Guy.

AutoGate NI is based in Belfast and works right across Northern Ireland, fitting new wrought iron, wooden, composite and aluminium gates as well as repairing the automation systems on existing ones.

## Starting out

[HOW THE BUSINESS STARTED]

## What's next

[PLANS FOR THE COMING YEAR]

> [A QUOTE FROM ADRIAN]

*This is a sample story showing how a pinned article looks. Edit it or replace it before launch.*
