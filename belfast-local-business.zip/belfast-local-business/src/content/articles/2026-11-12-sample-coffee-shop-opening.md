---
title: "Independent coffee shop opens its doors on the Lisburn Road"
description: "Sample article: a new opening story, showing how stories appear in the Latest column and the New Openings section."
date: 2026-11-12
category: new-openings
area: Lisburn Road
---

*This is a sample article to show the layout. Delete it before launch.*

A new opening story would go here: who's behind the business, what they offer, opening hours and where to find them.
