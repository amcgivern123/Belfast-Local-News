---
title: "Ormeau Road traders plan late-night Christmas shopping event"
description: "Sample article: a retail story, showing how stories appear in the Retail section."
date: 2026-11-11
category: retail
area: Ormeau Road
---

*This is a sample article to show the layout. Delete it before launch.*

A story about local traders working together would go here.
