---
title: "Free small business networking breakfast announced for December"
description: "Sample article: an events story, showing how stories appear in the Events section."
date: 2026-11-10
category: events
---

*This is a sample article to show the layout. Delete it before launch.*

Event details would go here: date, time, venue and how to book.
