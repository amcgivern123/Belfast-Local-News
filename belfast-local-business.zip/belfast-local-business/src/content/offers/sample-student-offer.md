---
business: "[SAMPLE] Your business name"
offer: "20% off for students"
area: Botanic
ends: 2026-12-31
details: "Sample offer to show the layout. Delete before launch."
---
