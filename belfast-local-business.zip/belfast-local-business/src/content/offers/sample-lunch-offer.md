---
business: "[SAMPLE] Your business name"
offer: "2 for 1 lunches, Mon–Wed"
area: Lisburn Road
ends: 2026-12-31
details: "Sample offer to show the layout. Delete before launch."
---
